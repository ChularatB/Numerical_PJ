import { Route, Routes } from 'react-router-dom';
// import axios from 'axios';
import Navbar from './Navbar';
import Root from './Root';
import Linear from './Linear';
import Interpolation from './Interpolation';
// import { useState , useEffect} from 'react';
// import { Router } from 'express';

// const [data, setData] = useState();

// axios.get('https://numer.chularatbunchan.repl.co/numer')
//   .then(response => {
//     console.log(response.data);
//   })
//   .catch(error => {
//     console.log(error);
//   });



export default function App() {
  return (
    <>
      <Navbar />
      <div>
        <Routes>
          <Route path='/Root' Component={<Root />} />
          <Route path='/Linear' Component={<Linear />} />
          <Route path='/Interpolation' Component={<Interpolation />} />
        </Routes>
      </div>
    </>
  );
}




