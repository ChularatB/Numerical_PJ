import Bisection from "./root/Bisection";
import False from "./root/False";
import Onep from "./root/Onep";
import Newton from "./root/Newton";
import Secant from "./root/Secant";

export default function Root() {
    return (
    <>
        <center>
            <h3>Bisection Method</h3>
                <Bisection />
            <hr />
            <h3>False Position Isolation</h3>
                <False />
            <hr />
            <h3>One point Method</h3>
                <Onep />
            <hr />
            <h3>Newton Rapson </h3>
                <Newton />
            <hr />
            <h3>Secant </h3>
                <Secant />
            <hr />

        </center>
    </>
        
    );
}


