import React from 'react';
import { evaluate, index } from "mathjs";
import { useState } from "react";
import { Button, Col, Container, Row, Table } from "react-bootstrap";
import { Line } from "react-chartjs-2";
import { CategoryScale,Chart,registerables } from "chart.js";

Chart.register(CategoryScale);
Chart.register(...registerables);

const Graphical = () => {
    const [html, setHtml] = useState(null);
    const [Equation, setEquation] = useState('(x^4)-13')
    const [X, setX] = useState();
    const [XX, setXX] = useState();
    const data =[];
    const [state, setState] = useState([]);
    const [valueIter, setValueIter] = useState([]);
    const [valuegX0, setValuegX0] = useState([]);
    const [valueX, setValueX] = useState([]);

    const inputEquation = (event) =>{
        console.log(event.target.value)
        setEquation(event.target.value)
    }

    const inputX = (event) =>{
        console.log(event.target.value)
        setX(event.target.value)
    }

    const error =(xold, xnew)=> Math.abs((xnew-xold)/xnew)*100;

    const Calgraph = (x) => {
        var gx0,scope,ea;
        var x1 = 0;
        var iter = 0;
        var MAX = 10;
        const e = 0.00001;
        var obj={};
        do
        {
            iter ++;
            x++;
            scope = {
                x:x,
            }
            gx0 = evaluate(Equation, scope)
            x = evaluate(Equation, scope)
            scope = {
                x:x1,
            }
            gx0 = evaluate(Equation, scope)
            obj = {
                Iteration:iter,
                X:x,
                X1:x1,
                gX0:gx0
            }
            data.push(obj);
            ea = error(x, x1);
            x = x1;
        }while(ea>e && iter<MAX)
        setX(x1)
    }

    const calculateRoot = () =>{
        const xnum = parseFloat(X)
        Calgraph(xnum);

        setHtml(print());

        console.log(valueIter)
        console.log(valueX)

        setState(data)

    }

    const dataX=[];
    const dataY=[];
    const graph = () => {
    {
        data.map((element,index) =>{
        dataX[index]= element.X;
        dataY[index]= element.gX0;
        })   }
        console.log("dataX"+dataX); 
        console.log("dataY"+dataY); 

    }
    const datagrapgh={
        labels : dataX,
        datasets:[
            {
                axis:'y',
                label: 'Answer',
                data: dataY,
                borderColor: 'black',
                fill: false,
                tension: 0.1
            }
        ]
    };
    const print = () =>{
        console.log(data)
        graph();
        setValueIter(data.map((XX)=>XX.iteration));
        setValueX(data.map((XX)=>XX.X));
        setValuegX0(data.map((XX)=>XX.gX0));

        return(
            <Container>
                 <Table>
                    <thead>
                        <tr>
                            <th width="30%">Iteration</th>
                            <th width="30%">X</th>
                            <th width="30%">g(X0)</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((element, index)=>{
                            return  (
                            <tr key={index}>
                                <td>{element.Iteration}</td>
                                <td>{element.X}</td>
                                <td>{element.gX0}</td>
                            </tr>)
                        })}
                    </tbody>
                </Table>
                <Line data={datagrapgh}/>
            </Container>
        );
    }

    return(
        <Container>
            <div>
            <form> 
                <label>Input f(x)   </label>
                <input type="text" id="equation" value={Equation} onChange={e => setEquation(e.target.value)} ></input><br></br><br></br>
                <label>Input X     </label>
                <input type="number" id="x" value={X} onChange={inputX} ></input><br></br><br></br>
                <Button onClick={calculateRoot}>Calculate</Button>
                <br></br>
                <h5>Ans = {X}</h5>
                <Container>
                {html}
                </Container>
                </form> 
            </div>
        </Container>
        );
    }

export default Graphical