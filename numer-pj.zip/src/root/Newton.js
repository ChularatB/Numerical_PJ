import React, { useState } from "react";
const math = require("mathjs");


const Newton = () => {
  const [equations, setEquations] = useState("(x^4)-13");
  const [xn, setXn] = useState("");
  const [result, setResult] = useState("");
  const inputEquations = (e) => {
    const value = e.target.value;
    setEquations(value);
  };

  const inputXn = (e) => {
    const value = e.target.value;
    setXn(value);
  };

  const calculate = () => {
    let x = Number(xn),
      error = 1,
      fx,
      dfx,
      xAbs;
    do {
      fx = math.evaluate(equations, { x: x });
      dfx = math.derivative(equations, "x").evaluate({ x: x });
      xAbs = (fx * -1) / dfx;
      x = x + xAbs;
      error = Math.abs(xAbs / x);
    } while (error >= 0.0001);
    setResult(x.toFixed(6));
  };
  return (
    <div className="App">
      <form>
        <div>
          <label>Input F(x):    </label>
          <input
            type="text"
            value={equations}
            onChange={inputEquations}
          /><br></br><br></br>
          <label>Input X(0): </label>
          <input
            type="text"
            value={xn}
            onChange={inputXn}
          />
        </div><br></br><br></br>
        <button type="button" onClick={calculate}>
          calculate
        </button>
      </form>
      <h4> Answer = {result}</h4>
    </div>
  );
};

export default Newton;