function Interpolation() {
    return (
        <center>
            <h3>Jacobi isolation Matrix</h3>
               
            <hr />
        </center>
    );
}

export default Interpolation;
