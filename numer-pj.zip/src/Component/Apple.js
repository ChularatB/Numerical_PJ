// import React from 'react';
// import axios from 'axios';

// export default function Apple() {
//     const [result, setResult] = useState();

//     const apple = async () => {
//         try{
//             let res = await axios.get("http://127.0.0.1:8000/");
//             let result = res.data;
//             setResult(result);
//         }catch(error){
//             console.error();
//         }
//     };

//     useEffect(() => {
//         apple()
//     },[])
//     if (!data) return null;

//     return(
//         <div>
//             {result}
//         </div>
//     )
// }
