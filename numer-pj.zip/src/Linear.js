
function Linear() {
    return (
        <center>
            <h3>Cramer Matrix</h3>
                
            <hr />
        </center>
    );
}

export default Linear;
